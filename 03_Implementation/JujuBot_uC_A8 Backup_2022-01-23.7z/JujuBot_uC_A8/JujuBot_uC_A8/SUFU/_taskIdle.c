﻿/*
 * _taskIdle.c
 *
 * Created: 03.04.2021 23:10:49
 *  Author: jayst
 */ 

#include "_taskIdle.h"

void taskIdle(uint8_t IsrTimer2Ticks)
{
//	CommunicationCtrl();
//	ServoCtrl(IsrTimer2Ticks);
}
