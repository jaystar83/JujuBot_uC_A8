/*
 * TWI_RxTx.h
 *
 * Created: 09.01.2022 18:07:52
 *  Author: jayst
 */ 


#ifndef TWI_RXTX_H_
#define TWI_RXTX_H_





#endif /* TWI_RXTX_H_ */