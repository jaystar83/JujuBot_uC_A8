/*
 * UART_Config.h
 *
 * Created: 09.01.2022 18:06:33
 *  Author: jayst
 */ 


#ifndef UART_CONFIG_H_
#define UART_CONFIG_H_





#endif /* UART_CONFIG_H_ */