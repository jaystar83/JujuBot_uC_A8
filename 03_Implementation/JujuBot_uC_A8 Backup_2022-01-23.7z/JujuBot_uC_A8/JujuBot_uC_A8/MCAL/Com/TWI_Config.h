/*
 * TWI_Config.h
 *
 * Created: 09.01.2022 18:08:16
 *  Author: jayst
 */ 


#ifndef TWI_CONFIG_H_
#define TWI_CONFIG_H_





#endif /* TWI_CONFIG_H_ */