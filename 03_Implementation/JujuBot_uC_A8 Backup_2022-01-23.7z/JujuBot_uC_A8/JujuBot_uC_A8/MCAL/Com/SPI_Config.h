/*
 * SPI_Config.h
 *
 * Created: 09.01.2022 18:07:03
 *  Author: jayst
 */ 


#ifndef SPI_CONFIG_H_
#define SPI_CONFIG_H_





#endif /* SPI_CONFIG_H_ */