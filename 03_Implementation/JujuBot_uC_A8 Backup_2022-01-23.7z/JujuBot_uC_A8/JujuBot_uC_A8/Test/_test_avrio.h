/*
 * _test_avrio.h
 *
 * Created: 24.05.2021 20:14:09
 *  Author: jayst
 */ 


#ifndef _TEST_AVRIO_H_
#define _TEST_AVRIO_H_

typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef unsigned long uint32_t;

typedef short int8_t;
typedef int int16_t;
typedef long int32_t;


#endif /* _TEST_AVRIO_H_ */