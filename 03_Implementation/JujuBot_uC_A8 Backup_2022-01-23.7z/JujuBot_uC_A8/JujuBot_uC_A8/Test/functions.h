#ifndef FUNCTIONS_H__INCLUDED
#define FUNCTIONS_H__INCLUDED

int sumValues(int a, int b);

char* returnChar();


#endif /* FUNCTIONS_H__INCLUDED */
