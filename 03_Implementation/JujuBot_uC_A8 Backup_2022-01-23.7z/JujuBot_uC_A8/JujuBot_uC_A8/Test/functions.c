#include "functions.h"

int sumValues(int a, int b) {
	return a+b;
}

char* returnChar(char *str) {
	return str;
}
