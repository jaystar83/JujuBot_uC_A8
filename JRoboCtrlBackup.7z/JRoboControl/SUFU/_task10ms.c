/*
 * _task10ms.c
 *
 * Created: 12.03.2021 21:43:39
 *  Author: jayst
 */ 
